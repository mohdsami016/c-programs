#include<stdio.h>
#include<string.h>
int main()
{
	char st[10];
	printf("enter the string\n");
	gets(st);
	puts(revst);
	return 0;
}
