#include<stdio.h>
int main()
{
	printf("welcome zoyab");
}
