#include<stdio.h>
int main()
{
	int a,b,sub;
	printf("enter two values");
	scanf("%d%d",&a,&b);
	sub=a-b;
	printf("the sub of two values=%d",+sub);
	return 0;
}
