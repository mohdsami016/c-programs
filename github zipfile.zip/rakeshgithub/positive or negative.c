#include<stdio.h>
int main()
{
	int a;
	printf("enter value of a");
	scanf("%d",&a);
	if(a>=0)
	{
		printf("the number is greater");
	}
	else
	print("the number is negative");
	return 0;
}
