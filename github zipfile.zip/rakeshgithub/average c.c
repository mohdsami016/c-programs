#include<stdio.h>
int main()
{
	float a,b,avg;
	printf("enter two values\n");
	scanf("%f%f",&a,&b);
	avg=(a+b)/2;
	printf("the average of two variables=%f",+avg);
	return 0;
}
