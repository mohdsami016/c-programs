#include<stdio.h>
int main()
{
	char st[10];
	printf("enter a string\n");
	gets(st);
	printf("the string is :\n");
	puts(st);
	return 0;
}
