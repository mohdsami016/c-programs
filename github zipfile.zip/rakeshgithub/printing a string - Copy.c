#include<stdio.h>
int main()
{
	char ch[20];
	printf("enter your string\n");
	gets(ch);
	printf("your string is:\n");
	printf("%s",ch);
	return 0;
}
